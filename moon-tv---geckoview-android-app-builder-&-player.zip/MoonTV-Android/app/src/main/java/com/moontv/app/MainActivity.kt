package com.moontv.app

import android.content.pm.ActivityInfo
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoView

/**
 * Main Activity for Moon TV.
 * Hosts the Mozilla GeckoView surface, attaches delegates for navigation,
 * pop-up blocking, and video fullscreen handling, and connects to uBlock Origin.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var geckoView: GeckoView
    private lateinit var geckoSession: GeckoSession
    private lateinit var geckoRuntime: GeckoRuntime

    private lateinit var topBar: View
    private lateinit var loadingProgressBar: ProgressBar
    private lateinit var ublockBadge: View
    private lateinit var ublockStatusText: TextView
    private lateinit var shieldIcon: ImageView
    private lateinit var btnRefresh: ImageButton

    private var canGoBack: Boolean = false
    private var isFullScreen: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initViews()
        setupGeckoEngine()
        setupBackNavigation()
        setupExtensionStatusListener()
    }

    private fun initViews() {
        geckoView = findViewById(R.id.geckoView)
        topBar = findViewById(R.id.topBar)
        loadingProgressBar = findViewById(R.id.loadingProgressBar)
        ublockBadge = findViewById(R.id.ublockBadge)
        ublockStatusText = findViewById(R.id.ublockStatusText)
        shieldIcon = findViewById(R.id.shieldIcon)
        btnRefresh = findViewById(R.id.btnRefresh)

        btnRefresh.setOnClickListener {
            geckoSession.reload()
            Toast.makeText(this, "Reloading Moon TV...", Toast.LENGTH_SHORT).show()
        }

        ublockBadge.setOnClickListener {
            val status = if (WebExtensionManager.isExtensionActive) {
                "uBlock Origin is ACTIVE\nFiltering ads, trackers, and malicious embeds."
            } else {
                "uBlock Origin is INITIALIZING...\nBundled XPI is being loaded into GeckoView."
            }
            Toast.makeText(this, status, Toast.LENGTH_LONG).show()
        }
    }

    private fun setupGeckoEngine() {
        Log.i(TAG, "Binding GeckoView and establishing session...")

        // Retrieve the pre-warmed GeckoRuntime singleton
        geckoRuntime = GeckoManager.getRuntime(this)

        // Create new GeckoSession
        geckoSession = GeckoSession().apply {
            // Content Delegate: handles HTML5 video full screen
            contentDelegate = object : GeckoSession.ContentDelegate {
                override fun onFullScreen(session: GeckoSession, fullScreen: Boolean) {
                    setFullScreenMode(fullScreen)
                }
            }

            // Navigation Delegate: blocks popup ad spam and tracks page history
            navigationDelegate = object : GeckoSession.NavigationDelegate {
                override fun onCanGoBack(session: GeckoSession, canGoBack: Boolean) {
                    this@MainActivity.canGoBack = canGoBack
                }

                override fun onNewSession(session: GeckoSession, uri: String): GeckoResult<GeckoSession>? {
                    // Suppress rogue popup tabs from pirate streaming servers
                    Log.i(TAG, "Suppressed popup ad attempt to open new session: $uri")
                    return GeckoResult.fromValue(null)
                }
            }

            // Progress Delegate: displays loading bar during navigation
            progressDelegate = object : GeckoSession.ProgressDelegate {
                override fun onPageStart(session: GeckoSession, url: String) {
                    loadingProgressBar.visibility = View.VISIBLE
                }

                override fun onPageStop(session: GeckoSession, success: Boolean) {
                    loadingProgressBar.visibility = View.GONE
                }
            }

            // Prompt Delegate: auto-approves built-in extension permission requests
            promptDelegate = object : GeckoSession.PromptDelegate {
                override fun onExtensionInstallPrompt(
                    session: GeckoSession,
                    prompt: GeckoSession.PromptDelegate.ExtensionInstallPrompt
                ): GeckoResult<GeckoSession.PromptDelegate.PromptResponse> {
                    Log.i(TAG, "Auto-approving uBlock Origin extension permission prompt")
                    return GeckoResult.fromValue(prompt.confirm())
                }
            }

            // Attach to the runtime
            open(geckoRuntime)
        }

        // Bind session to GeckoView
        geckoView.setSession(geckoSession)

        // Load Moon TV Home Page (via internal server with fallback to resource://)
        val homeUrl = "http://127.0.0.1:${MoonTvApplication.PORT}/index.html"
        Log.i(TAG, "Loading Moon TV Home Page: $homeUrl")
        geckoSession.loadUri(homeUrl)
    }

    private fun setupExtensionStatusListener() {
        WebExtensionManager.addStatusListener { active, message ->
            runOnUiThread {
                if (active) {
                    ublockStatusText.text = "uBlock ON"
                    ublockStatusText.setTextColor(ContextCompat.getColor(this, R.color.shield_green))
                    shieldIcon.setColorFilter(ContextCompat.getColor(this, R.color.shield_green))
                } else {
                    ublockStatusText.text = "uBlock INIT"
                    ublockStatusText.setTextColor(ContextCompat.getColor(this, R.color.text_secondary))
                    shieldIcon.setColorFilter(ContextCompat.getColor(this, R.color.text_secondary))
                }
            }
        }
    }

    private fun setupBackNavigation() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (isFullScreen) {
                    // Exit full screen first
                    setFullScreenMode(false)
                } else if (canGoBack) {
                    // Go back inside web history (e.g. movie details -> catalog)
                    geckoSession.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
    }

    /**
     * Toggles immersive full-screen video mode for movie playback.
     */
    private fun setFullScreenMode(fullScreen: Boolean) {
        isFullScreen = fullScreen
        runOnUiThread {
            if (fullScreen) {
                topBar.visibility = View.GONE
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    window.insetsController?.let { controller ->
                        controller.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                        controller.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                    }
                } else {
                    @Suppress("DEPRECATION")
                    window.decorView.systemUiVisibility = (
                        View.SYSTEM_UI_FLAG_FULLSCREEN or
                        View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                        View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    )
                }
            } else {
                topBar.visibility = View.VISIBLE
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    window.insetsController?.show(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                } else {
                    @Suppress("DEPRECATION")
                    window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        geckoSession.close()
    }

    companion object {
        private const val TAG = "MoonTvMainActivity"
    }
}
