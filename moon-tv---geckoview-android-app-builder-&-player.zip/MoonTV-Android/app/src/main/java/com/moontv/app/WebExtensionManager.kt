package com.moontv.app

import android.content.Context
import android.util.Log
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.WebExtension
import org.mozilla.geckoview.WebExtensionController
import java.io.File
import java.io.FileOutputStream

/**
 * Manages the lifecycle of bundled WebExtensions in GeckoView.
 * Automatically installs, enables, and verifies the supplied uBlock Origin XPI extension.
 */
object WebExtensionManager {
    private const val TAG = "WebExtensionManager"

    // The official Extension ID from uBlock Origin's manifest.json
    const val UBLOCK_EXTENSION_ID = "uBlock0@raymondhill.net"
    const val ASSET_EXTENSION_PATH = "extensions/ublock.xpi"

    @Volatile
    var uBlockExtension: WebExtension? = null
        private set

    @Volatile
    var isExtensionActive: Boolean = false
        private set

    private val statusListeners = mutableListOf<(Boolean, String) -> Unit>()

    /**
     * Initializes and registers the bundled uBlock Origin extension with GeckoView.
     * Uses ensureBuiltIn to guarantee automatic first-launch installation and
     * seamless persistence across restarts.
     */
    fun initialize(runtime: GeckoRuntime, context: Context) {
        val controller = runtime.webExtensionController

        // First check if already installed from previous sessions
        controller.list().accept(
            { extensions ->
                val existing = extensions?.find { it.id == UBLOCK_EXTENSION_ID }
                if (existing != null) {
                    Log.i(TAG, "uBlock Origin found in existing profile. Ensuring enabled...")
                    uBlockExtension = existing
                    enableExtension(controller, existing)
                } else {
                    Log.i(TAG, "uBlock Origin not found in profile. Installing bundled built-in XPI...")
                    installBundledExtension(controller, context)
                }
            },
            { throwable ->
                Log.w(TAG, "Error listing extensions, attempting direct install", throwable)
                installBundledExtension(controller, context)
            }
        )
    }

    private fun installBundledExtension(controller: WebExtensionController, context: Context) {
        // Primary path: Direct asset protocol in GeckoView
        val resourceUri = "resource://android/assets/$ASSET_EXTENSION_PATH"

        Log.i(TAG, "Installing built-in WebExtension from URI: $resourceUri")

        controller.ensureBuiltIn(resourceUri, UBLOCK_EXTENSION_ID).accept(
            { extension ->
                if (extension != null) {
                    Log.i(TAG, "uBlock Origin successfully installed as built-in: ${extension.id}")
                    uBlockExtension = extension
                    enableExtension(controller, extension)
                } else {
                    Log.w(TAG, "ensureBuiltIn returned null, trying extracted file path fallback...")
                    installFromExtractedFile(controller, context)
                }
            },
            { throwable ->
                Log.e(TAG, "Failed to install via resource:// URI, falling back to local file", throwable)
                installFromExtractedFile(controller, context)
            }
        )
    }

    /**
     * Fallback in case the asset protocol faces restricted sandbox constraints on certain Android versions.
     * Copies the XPI from APK assets to the app's internal cache and installs via file:// URI.
     */
    private fun installFromExtractedFile(controller: WebExtensionController, context: Context) {
        try {
            val extensionDir = File(context.filesDir, "extensions").apply { mkdirs() }
            val xpiFile = File(extensionDir, "ublock.xpi")

            if (!xpiFile.exists() || xpiFile.length() == 0L) {
                context.assets.open(ASSET_EXTENSION_PATH).use { input ->
                    FileOutputStream(xpiFile).use { output ->
                        input.copyTo(output)
                    }
                }
                Log.i(TAG, "Copied ublock.xpi to internal storage: ${xpiFile.absolutePath} (${xpiFile.length()} bytes)")
            }

            val fileUri = "file://${xpiFile.absolutePath}"
            controller.installBuiltIn(fileUri).accept(
                { extension ->
                    Log.i(TAG, "uBlock Origin installed from local file: ${extension?.id}")
                    uBlockExtension = extension
                    if (extension != null) {
                        enableExtension(controller, extension)
                    }
                },
                { throwable ->
                    Log.e(TAG, "Fatal: Failed to install uBlock Origin from extracted file", throwable)
                    notifyStatus(false, "Installation failed: ${throwable.message}")
                }
            )
        } catch (e: Exception) {
            Log.e(TAG, "Exception during fallback extension extraction", e)
            notifyStatus(false, "Extraction error: ${e.message}")
        }
    }

    private fun enableExtension(controller: WebExtensionController, extension: WebExtension) {
        controller.enable(extension, WebExtensionController.EnableSource.USER).accept(
            {
                Log.i(TAG, "uBlock Origin is ENABLED and actively protecting web sessions.")
                isExtensionActive = true
                notifyStatus(true, "uBlock Origin Active & Protecting")
            },
            { throwable ->
                Log.e(TAG, "Failed to enable uBlock Origin", throwable)
                notifyStatus(false, "Failed to enable: ${throwable.message}")
            }
        )
    }

    fun addStatusListener(listener: (Boolean, String) -> Unit) {
        statusListeners.add(listener)
        // Immediately invoke with current state
        listener(isExtensionActive, if (isExtensionActive) "uBlock Origin Active & Protecting" else "Initializing...")
    }

    fun removeStatusListener(listener: (Boolean, String) -> Unit) {
        statusListeners.remove(listener)
    }

    private fun notifyStatus(active: Boolean, message: String) {
        isExtensionActive = active
        statusListeners.forEach { it(active, message) }
    }
}
