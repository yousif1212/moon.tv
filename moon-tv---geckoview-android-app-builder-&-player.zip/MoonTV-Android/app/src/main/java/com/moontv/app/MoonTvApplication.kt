package com.moontv.app

import android.app.Application
import android.util.Log

/**
 * Application class for Moon TV.
 * Eagerly warms up the Mozilla GeckoRuntime and embedded asset server
 * to ensure near-instant first page load and extension activation.
 */
class MoonTvApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        Log.i(TAG, "Initializing Moon TV application with Mozilla GeckoView engine...")

        // Pre-initialize GeckoRuntime in background
        try {
            GeckoManager.init(this)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize GeckoRuntime", e)
        }

        // Start internal asset web server for standard HTTP origin context
        try {
            MoonTvWebServer.start(this, PORT)
            Log.i(TAG, "Moon TV internal server running on http://127.0.0.1:$PORT")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start Moon TV internal server", e)
        }
    }

    override fun onTerminate() {
        super.onTerminate()
        MoonTvWebServer.stop()
    }

    companion object {
        private const val TAG = "MoonTvApplication"
        const val PORT = 8080
    }
}
