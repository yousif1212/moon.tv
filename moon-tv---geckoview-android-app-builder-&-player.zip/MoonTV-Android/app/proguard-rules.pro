# ProGuard Rules for Moon TV with Mozilla GeckoView and WebExtensions

# Preserve GeckoView APIs and JNI methods
-keep class org.mozilla.geckoview.** { *; }
-keep interface org.mozilla.geckoview.** { *; }
-dontwarn org.mozilla.geckoview.**

# Preserve WebExtension Controller and interfaces
-keep class org.mozilla.geckoview.WebExtension** { *; }
-keep class org.mozilla.geckoview.GeckoResult** { *; }
-keep class org.mozilla.geckoview.GeckoSession** { *; }
-keep class org.mozilla.geckoview.GeckoRuntime** { *; }

# Preserve MoonTV internal classes
-keep class com.moontv.app.** { *; }
