#!/bin/bash
# Script to sign an unsigned APK with moon-tv.keystore
set -e

APK_INPUT="${1:-../app/build/outputs/apk/release/app-release-unsigned.apk}"
APK_OUTPUT="${2:-../app/build/outputs/apk/release/MoonTV-v1.0-signed.apk}"
KEYSTORE="moon-tv.keystore"
KEY_ALIAS="moontv"
STORE_PASS="moontv123"

if [ ! -f "$KEYSTORE" ]; then
    echo "Keystore not found. Generating new keystore..."
    bash generate_keystore.sh
fi

if [ ! -f "$APK_INPUT" ]; then
    echo "Input APK not found at $APK_INPUT"
    echo "Please build the release APK first: ./gradlew assembleRelease"
    exit 1
fi

echo "Signing APK: $APK_INPUT -> $APK_OUTPUT"
cp "$APK_INPUT" "$APK_OUTPUT"

# Sign with jarsigner or apksigner
if command -v apksigner >/dev/null 2>&1; then
    apksigner sign --ks "$KEYSTORE" --ks-pass "pass:$STORE_PASS" --ks-key-alias "$KEY_ALIAS" "$APK_OUTPUT"
    echo "Verified with apksigner:"
    apksigner verify --verbose "$APK_OUTPUT"
else
    jarsigner -verbose -sigalg SHA256withRSA -digestalg SHA-256 -keystore "$KEYSTORE" -storepass "$STORE_PASS" "$APK_OUTPUT" "$KEY_ALIAS"
    echo "Signed with jarsigner."
fi

echo "APK successfully signed: $APK_OUTPUT"
